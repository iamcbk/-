package com.sky.system.domain.config;

public class ServerEndpointExporter {
}
